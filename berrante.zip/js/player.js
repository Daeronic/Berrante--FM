var myMedia = null;
var i = 1;
var lista = [];
$.getJSON("https://alotofnothing.000webhostapp.com/pl/musica/leitura.php", function (data) {
    console.log("Foi a lista")
    $.each(data, function (val, name) {
        lista.push(name);
    });

});
var count = Math.floor(Math.random() * 10);
function playAudio() {

    if (myMedia === null) {
        myMedia = new Media(lista[count], onSuccess, onError);

        function onSuccess() {
            console.log("playAudio Success");
        }

        function onError(error) {
            console.log("playAudio Error: " + error.code);
        }
    }
    myMedia.play();
}